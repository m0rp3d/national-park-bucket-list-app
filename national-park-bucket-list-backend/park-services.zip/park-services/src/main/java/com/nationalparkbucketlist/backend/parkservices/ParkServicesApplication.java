package com.nationalparkbucketlist.backend.parkservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkServicesApplication.class, args);
	}

}
